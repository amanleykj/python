import numbers
from flask import Flask, render_template
app = Flask(__name__)


# @app.route('/')
# def hello_world(phrase):
#     return render_template("hello.html", phrase="Hello", times=5)


@app.route('/play')
def squares_one():
    return render_template("hello.html", num = 3, color = "blue")

@app.route('/play/<int:num>')
def squares_two(num):
    return render_template("hello.html", num = num, color = "blue")

@app.route('/play/<int:num>/<string:color>')
def squares_three(num, color):
    return render_template("hello.html", num = num, color = color)

# @app.route('/play/<int:x>')
# def level_one(x):
#     return render_template("hello.html", x = x)

# @app.route('/play/<int:x>/<string:color>')
# def level_one(x, color):
#     return render_template("hello.html", x = x, color = color)

# @app.route('/repeat/<int:num>/<string:word>')
# def repeater(num, word):
#     return f"Hello {num * word}

# @app.route('/hello/<name>/<id>')
# def hello(name, id):
#     return f"Hello {name}! Your ID is {id}."

if __name__=="__main__":
    app.run(debug=True)