from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
from user import User

app.secret_key = "1_2_3---!"


@app.route('/')
def index():
    return render_template("read_all.html", all_users = User.getAll())

@app.route('/create')
def create():
    return render_template ("create.html")

@app.route('/create_user', methods=['POST'])
def create_user():
    # if request.form['action'] == ['create_user']: DON'T USE UNLESS ACTUALLY NEEDED TO DIFFERENTIATE
    data_row = {
            "first_name" : request.form["first_name"],
            "last_name" : request.form["last_name"],
            "email" : request.form["email"]
        }

    user_id = User.save(data_row)
    session['user_id'] = user_id
    return redirect('/')

if __name__ == "__main__":
    app.run(debug=True)